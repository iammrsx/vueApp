export default {
    users : [],
    user: [],
    loader:false,
    query:""
}